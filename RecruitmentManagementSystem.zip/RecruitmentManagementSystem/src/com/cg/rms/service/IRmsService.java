package com.cg.rms.service;

import com.cg.rms.bean.CandidatePersonal;
import com.cg.rms.bean.CandidateWork;

public interface IRmsService {
	
	public CandidatePersonal addCandidate(CandidatePersonal cpersonal);	
	public CandidateWork addCandidate(CandidateWork cwork);	

}
