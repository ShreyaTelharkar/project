package com.cg.rms.bean;

public class CandidateWork {

	
	 String work_id;
	 String candidate_id;
	 String Which_employer;
	 String contact_person;
	 String Position_held;
	 String Company_name;
	 String Employment_form;
	 String Employment_to;
	 String Reason_For_leaving;
	 String Responsibilities;
	 String Hr_rep_name;
	 String Hr_rep_contact_name;
	 
	
		
	public String getWork_id() {
		return work_id;
	}
	public void setWork_id(String work_id) {
		this.work_id = work_id;
	}
	public String getCandidate_id() {
		return candidate_id;
	}
	public void setCandidate_id(String candidate_id) {
		this.candidate_id = candidate_id;
	}
	public String getWhich_employer() {
		return Which_employer;
	}
	public void setWhich_employer(String which_employer) {
		Which_employer = which_employer;
	}
	public String getContact_person() {
		return contact_person;
	}
	public void setContact_person(String contact_person) {
		this.contact_person = contact_person;
	}
	public String getPosition_held() {
		return Position_held;
	}
	public void setPosition_held(String position_held) {
		Position_held = position_held;
	}
	public String getCompany_name() {
		return Company_name;
	}
	public void setCompany_name(String company_name) {
		Company_name = company_name;
	}
	public String getEmployment_form() {
		return Employment_form;
	}
	public void setEmployment_form(String employment_form) {
		Employment_form = employment_form;
	}
	public String getEmployment_to() {
		return Employment_to;
	}
	public void setEmployment_to(String employment_to) {
		Employment_to = employment_to;
	}
	public String getReason_For_leaving() {
		return Reason_For_leaving;
	}
	public void setReason_For_leaving(String reason_For_leaving) {
		Reason_For_leaving = reason_For_leaving;
	}
	public String getResponsibilities() {
		return Responsibilities;
	}
	public void setResponsibilities(String responsibilities) {
		Responsibilities = responsibilities;
	}
	public String getHr_rep_name() {
		return Hr_rep_name;
	}
	public void setHr_rep_name(String hr_rep_name) {
		Hr_rep_name = hr_rep_name;
	}
	public String getHr_rep_contact_name() {
		return Hr_rep_contact_name;
	}
	public void setHr_rep_contact_name(String hr_rep_contact_name) {
		Hr_rep_contact_name = hr_rep_contact_name;
	}
	
	@Override
	public String toString() {
		return "CandidateWork [work_id=" + work_id + ", candidate_id="
				+ candidate_id + ", Which_employer=" + Which_employer
				+ ", contact_person=" + contact_person + ", Position_held="
				+ Position_held + ", Company_name=" + Company_name
				+ ", Employment_form=" + Employment_form + ", Employment_to="
				+ Employment_to + ", Reason_For_leaving=" + Reason_For_leaving
				+ ", Responsibilities=" + Responsibilities + ", Hr_rep_name="
				+ Hr_rep_name + ", Hr_rep_contact_name=" + Hr_rep_contact_name
				+ "]";
	}	  
}
