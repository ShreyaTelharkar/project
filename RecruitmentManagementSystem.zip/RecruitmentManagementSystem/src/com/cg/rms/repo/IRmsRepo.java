package com.cg.rms.repo;

import com.cg.rms.bean.CandidatePersonal;
import com.cg.rms.bean.CandidateWork;



public interface IRmsRepo {
	
	public CandidatePersonal addCandidate(CandidatePersonal cpersonal);	
    public CandidateWork addCandidate(CandidateWork cwork);
}
